import java.util.Scanner; //we will need the scanner for user input

public class Exercise3 
{ //name of the class
	
	public static void main(String[] args)
	{ // main method
		
	}
}
